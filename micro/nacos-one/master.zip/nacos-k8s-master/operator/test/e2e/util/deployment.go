package util

func waitForDeploymentPodReady() error {
	return nil
}
